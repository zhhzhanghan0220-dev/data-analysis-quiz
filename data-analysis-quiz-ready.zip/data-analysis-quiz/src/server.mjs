import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { createQuizServer } from './mcp.mjs';
const html = readFileSync(new URL('../dist/quiz.html',import.meta.url),'utf8');
const port = Number(process.env.PORT || 8787);
const http = createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(url.pathname==='/health'){res.writeHead(200,{'Content-Type':'application/json'}).end('{"ok":true}');return;}
 if(url.pathname==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'}).end('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>资料分析答题器</title><h1>资料分析答题器已启动</h1><p>请在ChatGPT中连接此服务的 /mcp 地址，由ChatGPT生成资料和题目后打开答题界面。</p></html>');return;}
 if(url.pathname!=='/mcp'){res.writeHead(404).end('Not found');return;}
 if(req.method==='OPTIONS'){res.writeHead(204,{'Allow':'POST, GET, OPTIONS'}).end();return;}
 if(req.method!=='POST'){res.writeHead(405,{'Allow':'POST','Content-Type':'application/json'}).end(JSON.stringify({jsonrpc:'2.0',error:{code:-32000,message:'Method not allowed'},id:null}));return;}
 const origin=req.headers.origin;
 if(origin && !/^https:\/\/([\w-]+\.)?(chatgpt\.com|openai\.com)$/.test(origin) && origin !== `http://localhost:${port}` && origin !== `http://127.0.0.1:${port}`){res.writeHead(403).end('Origin not allowed');return;}
 const server=createQuizServer(html);
 const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableJsonResponse:true});
 res.on('close',()=>{void transport.close();void server.close();});
 try{await server.connect(transport);await transport.handleRequest(req,res);}catch(e){console.error('MCP request failed:',e.message);if(!res.headersSent)res.writeHead(500).end('Internal server error');}
});
http.listen(port,'0.0.0.0',()=>console.log(`资料分析答题器 http://localhost:${port}/mcp`));
for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>http.close(()=>process.exit(0)));

export const LETTERS = ['A', 'B', 'C', 'D'];
export function validateQuiz(q) {
  if (!q || typeof q.title !== 'string' || !q.title.trim() || typeof q.material !== 'string' || !q.material.trim()) throw new Error('请提供标题和资料（Markdown）。');
  if (!Array.isArray(q.questions) || q.questions.length !== 5) throw new Error('每篇材料必须有5道题。');
  const ids = new Set();
  for (const item of q.questions) {
    if (!item || !Number.isInteger(item.id) || item.id < 1 || item.id > 5 || ids.has(item.id)) throw new Error('题号必须为不重复的1—5。');
    ids.add(item.id);
    if (typeof item.stem !== 'string' || !item.stem.trim() || !LETTERS.every(k => typeof item.options?.[k] === 'string' && item.options[k].trim())) throw new Error('每题必须包含题干和A/B/C/D选项。');
  }
  return { title: q.title, material: q.material, questions: [...q.questions].sort((a,b)=>a.id-b.id) };
}
export function formatTime(seconds) { return `${Math.floor(seconds / 60)}分${seconds % 60}秒`; }
export function makeResult({quizId, title, answers, elapsedSeconds, submissionId}) {
  if (!Array.isArray(answers) || answers.length !== 5 || answers.some(a => !Number.isInteger(a.id) || a.id < 1 || a.id > 5 || !LETTERS.includes(a.choice)) || new Set(answers.map(a=>a.id)).size !== 5) throw new Error('请完成全部5题后交卷。');
  if (!Number.isInteger(elapsedSeconds) || elapsedSeconds < 0) throw new Error('用时无效。');
  const ordered = [...answers].sort((a,b)=>a.id-b.id);
  const summary = ordered.map(a=>`${a.id}${a.choice}`).join(' ');
  return {quizId, submissionId, title, answers: ordered, elapsedSeconds, elapsed: formatTime(elapsedSeconds), summary, text: `${title}\n${summary}\n总用时：${formatTime(elapsedSeconds)}`};
}
export class QuizSession {
  constructor(quiz, quizId, now = () => Date.now()) { this.quiz = validateQuiz(quiz); this.quizId = quizId; this.now = now; this.startedAt = now(); this.answers = {}; this.index = 0; this.result = null; }
  choose(letter) { if (!this.result && LETTERS.includes(letter)) this.answers[this.quiz.questions[this.index].id] = letter; }
  move(index) { if (Number.isInteger(index) && index >= 0 && index < 5) this.index = index; }
  elapsed() { return this.result?.elapsedSeconds ?? Math.max(0, Math.floor((this.now() - this.startedAt)/1000)); }
  submit(submissionId) { if (this.result) return this.result; this.result = makeResult({quizId:this.quizId,title:this.quiz.title,answers:this.quiz.questions.map(q=>({id:q.id,choice:this.answers[q.id]})),elapsedSeconds:this.elapsed(),submissionId}); return this.result; }
}

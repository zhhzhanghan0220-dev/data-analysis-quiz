import test from 'node:test';
import assert from 'node:assert/strict';
import {QuizSession,validateQuiz,makeResult} from '../src/core.mjs';
import {markdown} from '../web/markdown.mjs';
const quiz={title:'测试练习',material:'材料',questions:Array.from({length:5},(_,i)=>({id:i+1,stem:'题目',options:{A:'甲',B:'乙',C:'丙',D:'丁'}}))};
test('5题、唯一题号及完整选项验证',()=>{assert.equal(validateQuiz(quiz).questions.length,5);assert.throws(()=>validateQuiz({...quiz,questions:quiz.questions.slice(1)}));assert.throws(()=>validateQuiz({...quiz,questions:quiz.questions.map(q=>({...q,id:1}))}));});
test('选择、切题、修改、未完成提示、停止计时与重复交卷',()=>{let now=1000;const s=new QuizSession(quiz,'quiz',()=>now);s.choose('A');s.move(1);s.choose('C');s.move(0);s.choose('D');assert.equal(s.answers[1],'D');assert.throws(()=>s.submit('id'));for(let i=2;i<5;i++){s.move(i);s.choose('B');}now+=462000;const r=s.submit('id');assert.equal(r.summary,'1D 2C 3B 4B 5B');assert.equal(r.elapsed,'7分42秒');now+=999999;assert.equal(s.elapsed(),462);s.choose('A');assert.equal(s.answers[5],'B');assert.equal(s.submit('other'),r);});
test('拒绝错误或重复的提交题号',()=>{assert.throws(()=>makeResult({answers:Array.from({length:5},()=>({id:1,choice:'A'})),elapsedSeconds:1}));});
test('安全Markdown支持加粗、多段和表格，不执行HTML',()=>{const out=markdown('第一段**100**\n\n第二段\n\n| 年份 | 金额 |\n| --- | --- |\n| 2025 | **23** |\n\n<script>alert(1)</script>');assert.match(out,/<strong>100<\/strong>/);assert.match(out,/<table>/);assert.match(out,/&lt;script&gt;/);assert.doesNotMatch(out,/<script>/);});

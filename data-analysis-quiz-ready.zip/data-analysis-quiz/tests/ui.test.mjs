import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import vm from 'node:vm';
import {QuizSession,LETTERS} from '../src/core.mjs';import {markdown} from '../web/markdown.mjs';
class Element {
 constructor(){this.children=[];this.attributes={};this.scrollTop=0;this.hidden=false;this.classes=new Set();this.classList={toggle:(k,v)=>v?this.classes.add(k):this.classes.delete(k)};}
 append(...items){for(const x of items){x.parent=this;this.children.push(x);}}
 insertBefore(x,other){x.parent=this;this.children.splice(this.children.indexOf(other),0,x);}
 replaceChildren(...items){this.children=[];this.append(...items);}
 querySelectorAll(){return this.children.filter(x=>x.tag==='button');}
 remove(){this.parent.children=this.parent.children.filter(x=>x!==this);}
 setAttribute(k,v){this.attributes[k]=v;}
 removeAttribute(k){delete this.attributes[k];}
}
const fixture={quizId:'a-quiz',quiz:{title:'动态练习',material:'资料**123**',questions:Array.from({length:5},(_,i)=>({id:i+1,stem:`题${i+1}`,options:{A:'a',B:'b',C:'c',D:'d'}}))}};
function setup(){let app,now=0,fail=false;const calls=[],elements=new Map();const el=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};el('nav').append(el('progress'));
 class App{constructor(){app=this;}connect(){return Promise.resolve();}async sendSizeChanged(){}getHostContext(){return {theme:'dark'};}async callServerTool(args){calls.push(['tool',args]);if(fail)throw Error('network');return {content:[]};}async updateModelContext(args){calls.push(['context',args]);}async sendMessage(args){calls.push(['message',args]);return {};}}
 const document={getElementById:el,createElement:tag=>{const x=new Element();x.tag=tag;return x;},documentElement:{dataset:{},style:{setProperty(){}}}};
 class FakeSession extends QuizSession{constructor(q,id){super(q,id,()=>now);}}
 const code=readFileSync('web/app.mjs','utf8').replace(/^import .*;\n/gm,'');
 const context={App,QuizSession:FakeSession,LETTERS,markdown,document,window:{parent:{}},crypto:{randomUUID:()=> 'submission'},setInterval(){}};vm.runInNewContext(code,context);app.ontoolresult({structuredContent:fixture});return {el,calls,app,time:x=>now=x,fail:x=>fail=x};}
test('UI：切题保留材料位置，导航状态和改答正确',()=>{const t=setup();t.el('material').scrollTop=240;const original=t.el('material').innerHTML;t.el('options').children[0].onclick();t.el('next').onclick();assert.equal(t.el('material').scrollTop,240);assert.equal(t.el('material').innerHTML,original);t.el('options').children[2].onclick();t.el('prev').onclick();assert.equal(t.el('options').children[0].attributes['aria-pressed'],'true');t.el('options').children[1].onclick();assert.equal(t.el('options').children[1].attributes['aria-pressed'],'true');assert.equal(t.el('progress').textContent,'已答 2/5');t.app.ontoolresult({structuredContent:fixture});assert.equal(t.el('material').scrollTop,240);});
test('UI：未答完提示，完整交卷发送工具结果、上下文和消息',async()=>{const t=setup();await t.el('submit').onclick();assert.match(t.el('notice').textContent,/完成全部5题/);assert.equal(t.calls.length,0);for(let i=0;i<5;i++){t.el('nav').children[i].onclick();t.el('options').children[i%4].onclick();}t.time(462000);await t.el('submit').onclick();assert.deepEqual(t.calls.map(x=>x[0]),['tool','context','message']);assert.equal(t.calls[0][1].arguments.elapsedSeconds,462);assert.equal(t.calls[1][1].structuredContent.summary,'1A 2B 3C 4D 5A');assert.equal(t.el('timer').textContent,'07:42');assert.equal(t.el('submit').disabled,true);assert.equal(t.el('options').children[0].disabled,true);});
test('UI：发送失败保留答案和停止时刻，重试不会重新计时',async()=>{const t=setup();for(let i=0;i<5;i++){t.el('nav').children[i].onclick();t.el('options').children[0].onclick();}t.time(10000);t.fail(true);await t.el('submit').onclick();assert.equal(t.el('submit').textContent,'重试发送');t.time(80000);t.fail(false);await t.el('submit').onclick();assert.equal(t.calls[1][1].arguments.elapsedSeconds,10);assert.equal(t.el('timer').textContent,'00:10');});

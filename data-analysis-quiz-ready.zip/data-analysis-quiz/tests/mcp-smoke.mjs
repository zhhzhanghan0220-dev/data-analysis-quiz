import assert from 'node:assert/strict';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StreamableHTTPClientTransport} from '@modelcontextprotocol/sdk/client/streamableHttp.js';
const client=new Client({name:'quiz-smoke',version:'1.0.0'});
await client.connect(new StreamableHTTPClientTransport(new URL(process.env.MCP_URL??'http://127.0.0.1:8787/mcp')));
try {
 const {tools}=await client.listTools();
 const show=tools.find(t=>t.name==='show_data_analysis_quiz');
 assert.equal(show._meta.ui.resourceUri,'ui://data-analysis-quiz/v1.html');
 const resources=await client.listResources();assert.ok(resources.resources.some(r=>r.uri===show._meta.ui.resourceUri));
 const resource=await client.readResource({uri:show._meta.ui.resourceUri});assert.equal(resource.contents[0].mimeType,'text/html;profile=mcp-app');assert.ok(resource.contents[0].text.includes('资料分析'));
 const quiz={title:'接口检查',material:'第一段**100**\n\n| 年份 | 数值 |\n| --- | --- |\n| 2025 | 100 |',questions:Array.from({length:5},(_,i)=>({id:i+1,stem:'接口测试题',options:{A:'甲',B:'乙',C:'丙',D:'丁'}}))};
 const opened=await client.callTool({name:'show_data_analysis_quiz',arguments:quiz});assert.ok(!opened.isError);assert.equal(opened.structuredContent.quiz.questions.length,5);
 const submitted=await client.callTool({name:'submit_data_analysis_quiz',arguments:{quizId:opened.structuredContent.quizId,submissionId:crypto.randomUUID(),title:quiz.title,answers:['A','C','B','D','A'].map((choice,i)=>({id:i+1,choice})),elapsedSeconds:462}});
 assert.equal(submitted.structuredContent.summary,'1A 2C 3B 4D 5A');assert.equal(submitted.structuredContent.elapsed,'7分42秒');assert.ok(!('correctAnswers' in submitted.structuredContent));
 console.log('MCP初始化、工具发现、UI资源、动态出题、交卷结果通过');
}finally{await client.close();}

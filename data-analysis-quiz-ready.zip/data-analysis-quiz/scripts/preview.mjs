import {createServer} from 'node:http';import {readFileSync} from 'node:fs';
const html=readFileSync('dist/quiz.html');createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'}).end(html);}).listen(8788,'127.0.0.1',()=>console.log('本地组件检查 http://127.0.0.1:8788'));

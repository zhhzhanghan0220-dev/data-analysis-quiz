import { build } from 'esbuild';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
await mkdir('dist',{recursive:true});
const result=await build({entryPoints:['web/app.mjs'],bundle:true,format:'iife',target:'es2022',write:false,minify:true});
const template=await readFile('web/template.html','utf8');
const js=result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
await writeFile('dist/quiz.html',template.replace('/* APP_BUNDLE */',js));
console.log('已生成 dist/quiz.html');

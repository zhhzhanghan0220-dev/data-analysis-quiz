# 公务员考试资料分析答题器

这是 ChatGPT MCP App，不是旧版 Plugin，也不是只在普通浏览器里运行的答题网页。

## 当前状态

- 已编写：官方 Node MCP SDK 服务、MCP Apps UI、动态试题输入、交卷工具、中文响应式布局、Docker 和 Render 配置。
- 已验证：7项本地逻辑测试，涵盖验证输入、选择与改答、切题保留材料滚动位置、未完成提示、停止计时、交卷消息及发送重试。UI测试使用模拟的DOM和宿主桥，不能替代浏览器或真实ChatGPT验证。
- 未完成：本环境网络权限拒绝访问 npm 代理，依赖无法安装。因此生产构建、实际服务启动、/mcp 联调、浏览器布局验证、ChatGPT接入和公网部署均未验证。不能把此项目描述为已上线。

## 现在最简单的下一步

在 ChatGPT 中安装并连接 GitHub 和 Render，完成各自的账号授权后，告诉助手“已连接”。后续由助手接着处理源代码发布、服务部署和接入验证，不需要你上传文件或编写代码。连接能力尚未实际确认，部署成功前没有可用公网地址。

如果服务提供方展示收费选项，不要确认付费；由助手先检查免费方案和当前账户条件。

## 使用方式

连接完成后对 ChatGPT 说：

> 请生成一篇公务员考试资料分析材料和5道四选一题。把正确答案和解析留到我交卷后，调用 show_data_analysis_quiz 打开交互答题器。材料用 Markdown，表格用管道表格；题号为1—5。

工具不接收、不保存正确答案，不会自动判分。ChatGPT须保留自行生成的答案与解析，交卷后根据用户选择分析。

## 本地运行（技术人员）

需要 Node.js 22或以上：

```sh
npm install
npm run build
npm test
npm start
```

另开终端执行 `npm run test:mcp`，检查真实HTTP端点的初始化、工具发现、UI资源和交卷结果。默认地址 http://localhost:8787/mcp；公网用HTTPS反向代理或Render自动TLS。`PORT` 为唯一可选配置。

`npm run test:ui` 是使用模拟DOM与桥的交互逻辑测试，不是浏览器测试。

## 工具输入

`show_data_analysis_quiz` 接收：

```json
{
  "title": "练习标题",
  "material": "第一段文字，关键数字为**123**。\n\n第二段文字。\n\n| 年份 | 数值 |\n| --- | --- |\n| 2025 | **123** |",
  "questions": [
    {"id":1,"stem":"第1题题干","options":{"A":"选项A","B":"选项B","C":"选项C","D":"选项D"}},
    {"id":2,"stem":"第2题题干","options":{"A":"选项A","B":"选项B","C":"选项C","D":"选项D"}},
    {"id":3,"stem":"第3题题干","options":{"A":"选项A","B":"选项B","C":"选项C","D":"选项D"}},
    {"id":4,"stem":"第4题题干","options":{"A":"选项A","B":"选项B","C":"选项C","D":"选项D"}},
    {"id":5,"stem":"第5题题干","options":{"A":"选项A","B":"选项B","C":"选项C","D":"选项D"}}
  ]
}
```

材料支持多段、换行、`**加粗**`、管道表格。原始HTML只显示为文字。图片/图表尚未实现，可在以后扩展渲染器和资源CSP。

`submit_data_analysis_quiz` 仅对 app 可见，不绑定渲染资源，避免交卷时重新创建答题界面。返回5个 `{id, choice}`、`elapsedSeconds`、中文用时和汇总文本。组件调用工具后使用标准 `updateModelContext` 和 `sendMessage` 将答卷带回对话。初始工具调用不会一直挂起等待答题。

答题状态只在当前组件内存中保存，卸载或刷新会丢失。计时从资料首次载入起按实际经过时间计算，首次完整交卷时停止；网络重试不增加答题用时。后端无数据库、登录或OpenAI API调用，也不记录答题请求体。

## 官方规范参考

核对日期：2026-10-12。

- https://developers.openai.com/plugins/build/app-quickstart
- https://developers.openai.com/plugins/build/chatgpt-ui
- https://developers.openai.com/plugins/reference
- https://apps.extensions.modelcontextprotocol.io/api/classes/app.App.html

采用官方 `@modelcontextprotocol/sdk`、`@modelcontextprotocol/ext-apps` 与 Zod；UI通过 `_meta.ui.resourceUri` 和 `text/html;profile=mcp-app` 注册，使用官方 App 桥通信。使用无状态 Streamable HTTP POST `/mcp`（JSON响应是标准允许的模式）；不提供常驻 GET SSE，GET返回405。保留 outputTemplate 兼容别名，但没有旧版 ai-plugin.json。

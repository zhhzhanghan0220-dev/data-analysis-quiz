(()=>{
 const $=id=>document.getElementById(id), LETTERS=['A','B','C','D'];
 let data=null,index=0,answers={},start=Date.now(),stopped=null,sending=false;
 function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
 function md(text){
  const lines=String(text).split(/\r?\n/),out=[];let i=0;
  const inline=s=>esc(s).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
  while(i<lines.length){
   if(/^\s*\|.*\|\s*$/.test(lines[i]) && i+1<lines.length && /^\s*\|?(?:\s*:?-+:?\s*\|)+\s*$/.test(lines[i+1])){
    const split=l=>l.trim().replace(/^\||\|$/g,'').split('|').map(x=>x.trim());
    const head=split(lines[i]);i+=2;const rows=[];while(i<lines.length&&/^\s*\|.*\|\s*$/.test(lines[i]))rows.push(split(lines[i++]));
    out.push('<div class="table-wrap"><table><thead><tr>'+head.map(x=>`<th>${inline(x)}</th>`).join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(x=>`<td>${inline(x)}</td>`).join('')+'</tr>').join('')+'</tbody></table></div>');continue;
   }
   if(!lines[i].trim()){i++;continue;}
   const p=[];while(i<lines.length&&lines[i].trim()&&!/^\s*\|.*\|\s*$/.test(lines[i]))p.push(lines[i++]);out.push(`<p>${inline(p.join('\n')).replace(/\n/g,'<br>')}</p>`);
  }return out.join('');
 }
 function elapsed(){return stopped??Math.floor((Date.now()-start)/1000)}
 function tick(){const n=elapsed();$('timer').textContent=`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;}
 function render(){if(!data)return;const q=data.quiz.questions[index];$('question-tag').textContent=`第 ${q.id} 题 / 共 5 题`;$('stem').textContent=q.stem;$('options').replaceChildren();LETTERS.forEach(k=>{const b=document.createElement('button');b.className='option';b.setAttribute('aria-pressed',String(answers[q.id]===k));const l=document.createElement('span');l.className='letter';l.textContent=k;const t=document.createElement('span');t.textContent=q.options[k];b.append(l,t);b.onclick=()=>{answers[q.id]=k;render();$('notice').textContent='已保存选择，可随时修改。';};$('options').append(b);});$('nav').querySelectorAll('button[data-q]').forEach((b,i)=>{b.classList.toggle('current',i===index);b.classList.toggle('answered',!!answers[data.quiz.questions[i].id]);});$('progress').textContent=`已答 ${Object.keys(answers).length}/5`;$('prev').disabled=index===0;$('next').disabled=index===4;}
 function load(candidate){if(!candidate?.quiz||!candidate?.quizId)return false;if(data?.quizId===candidate.quizId)return true;data=candidate;index=0;answers={};start=Date.now();stopped=null;$('title').textContent=data.quiz.title;$('material').innerHTML=md(data.quiz.material);$('workspace').hidden=false;$('empty').hidden=true;$('nav').querySelectorAll('button[data-q]').forEach(b=>b.remove());data.quiz.questions.forEach((q,i)=>{const b=document.createElement('button');b.dataset.q='1';b.textContent=q.id;b.onclick=()=>{index=i;render();$('question-scroll').scrollTop=0;};$('nav').insertBefore(b,$('progress'));});render();tick();return true;}
 function refresh(){try{load(window.openai?.view?.params?.quizData)||load(window.openai?.toolOutput);}catch(e){$('empty').textContent='题目载入失败：'+(e?.message||e);}}
 $('prev').onclick=()=>{if(index>0){index--;render();$('question-scroll').scrollTop=0;}};$('next').onclick=()=>{if(index<4){index++;render();$('question-scroll').scrollTop=0;}};
 $('submit').onclick=async()=>{if(!data||sending)return;if(Object.keys(answers).length<5){$('notice').textContent='请先完成全部5题。';$('notice').className='error';return;}sending=true;stopped=elapsed();tick();$('timer-label').textContent='最终用时';$('submit').disabled=true;$('notice').className='';$('notice').textContent='正在交卷…';const answerList=data.quiz.questions.map(q=>({id:q.id,choice:answers[q.id]}));const summary=answerList.map(x=>`${x.id}${x.choice}`).join(' ');const text=`${summary} · 总用时 ${Math.floor(stopped/60)}分${stopped%60}秒`;try{const api=window.openai;if(!api?.callTool)throw new Error('当前客户端无法提交答卷');const res=await api.callTool('submit_data_analysis_quiz',{quizId:data.quizId,submissionId:crypto.randomUUID(),title:data.quiz.title,answers:answerList,elapsedSeconds:stopped});if(res?.isError)throw new Error('答卷提交失败');$('notice').textContent='已交卷，正在返回 ChatGPT…';if(api.sendFollowUpMessage)await api.sendFollowUpMessage({prompt:`我已交卷，请分析我的正确率、计算速度和错因。\n${text}`,scrollToBottom:true});$('notice').textContent='已交卷，答案和用时已返回 ChatGPT。';}catch(e){$('notice').className='error';$('notice').textContent=(e?.message||'发送失败')+'；答案仍保留，可再次点击交卷。';$('submit').disabled=false;}finally{sending=false;}};
 window.addEventListener('openai:set_globals',refresh,{passive:true});refresh();setTimeout(refresh,0);setTimeout(refresh,250);setTimeout(refresh,1000);setInterval(tick,500);
})();

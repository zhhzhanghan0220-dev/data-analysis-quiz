(()=>{
  const QUIZ_URI='ui://data-analysis-quiz-modal/quiz-final-v2.html';
  const $=id=>document.getElementById(id);
  let data=null;
  function apply(candidate){
    if(!candidate?.quiz||!candidate?.quizId)return false;
    data=candidate;
    $('title').textContent=candidate.quiz.title;
    $('meta').textContent='5道题 · 点击后在 ChatGPT 内打开答题窗口';
    $('status').textContent='准备完成';
    $('open').disabled=false;
    return true;
  }
  function refresh(){
    try{apply(window.openai?.toolOutput);}catch(e){$('status').textContent='读取题目失败';}
  }
  window.addEventListener('openai:set_globals',refresh,{passive:true});
  $('open').addEventListener('click',async()=>{
    if(!data)return;
    const btn=$('open');btn.disabled=true;$('status').textContent='正在打开…';
    try{
      const api=window.openai;
      if(!api?.requestModal)throw new Error('当前客户端不支持应用内窗口');
      await api.requestModal({template:QUIZ_URI,params:{quizData:data}});
      $('status').textContent='答题窗口已打开';
    }catch(e){$('status').textContent=e?.message||'打开失败';btn.disabled=false;}
  });
  refresh();
  setTimeout(refresh,0);setTimeout(refresh,250);setTimeout(refresh,1000);
})();

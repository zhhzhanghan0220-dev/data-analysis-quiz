import { readFile, mkdir, writeFile } from 'node:fs/promises';
await mkdir('dist',{recursive:true});
for (const name of ['launcher','quiz']) {
  const template=await readFile(`web/${name}.html`,'utf8');
  const js=(await readFile(`web/${name}.js`,'utf8')).replace(/<\/script/gi,'<\\/script');
  await writeFile(`dist/${name}.html`,template.replace('/* APP_BUNDLE */',js));
}
console.log('已生成 dist/launcher.html 与 dist/quiz.html');

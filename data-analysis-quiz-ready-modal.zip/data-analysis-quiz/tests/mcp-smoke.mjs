import assert from 'node:assert/strict';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StreamableHTTPClientTransport} from '@modelcontextprotocol/sdk/client/streamableHttp.js';
const client=new Client({name:'quiz-smoke',version:'2.0.0'});
await client.connect(new StreamableHTTPClientTransport(new URL(process.env.MCP_URL??'http://127.0.0.1:8787/mcp')));
try {
 const {tools}=await client.listTools();
 const show=tools.find(t=>t.name==='show_data_analysis_quiz');
 assert.equal(show._meta.ui.resourceUri,'ui://data-analysis-quiz-modal/launcher-final-v2.html');
 const resources=await client.listResources();
 for(const uri of ['ui://data-analysis-quiz-modal/launcher-final-v2.html','ui://data-analysis-quiz-modal/quiz-final-v2.html']){
   assert.ok(resources.resources.some(r=>r.uri===uri));
   const resource=await client.readResource({uri});
   assert.equal(resource.contents[0].mimeType,'text/html;profile=mcp-app');
   assert.ok(resource.contents[0].text.includes('资料分析'));
 }
 const quiz={title:'接口检查',material:'第一段**100**',questions:Array.from({length:5},(_,i)=>({id:i+1,stem:'接口测试题',options:{A:'甲',B:'乙',C:'丙',D:'丁'}}))};
 const opened=await client.callTool({name:'show_data_analysis_quiz',arguments:quiz});
 assert.ok(!opened.isError);assert.equal(opened.structuredContent.quiz.questions.length,5);
 console.log('MCP工具与双UI资源通过');
}finally{await client.close();}

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { registerAppTool, registerAppResource, RESOURCE_MIME_TYPE } from '@modelcontextprotocol/ext-apps/server';
import { z } from 'zod';
import { randomUUID } from 'node:crypto';
import { validateQuiz, makeResult } from './core.mjs';

export const LAUNCHER_URI = 'ui://data-analysis-quiz-modal/launcher-final-v1.html';
export const QUIZ_URI = 'ui://data-analysis-quiz-modal/quiz-final-v1.html';
const text = z.string().min(1).max(50000);
const question = z.object({
  id:z.number().int().min(1).max(5),
  stem:text,
  options:z.object({A:text,B:text,C:text,D:text})
});

export function createQuizServer({launcherHtml, quizHtml}) {
  const server = new McpServer({name:'data-analysis-quiz-modal',version:'2.0.0'});

  registerAppResource(server,'data-analysis-quiz-launcher',LAUNCHER_URI,{},async()=>({contents:[{
    uri:LAUNCHER_URI,
    mimeType:RESOURCE_MIME_TYPE,
    text:launcherHtml,
    _meta:{
      ui:{prefersBorder:true,csp:{connectDomains:[],resourceDomains:[]}},
      'openai/ui':{availableDisplayModes:['inline']},
      'openai/widgetPrefersBorder':true,
      'openai/widgetDescription':'资料分析练习启动卡片，点击“打开答题器”后在 ChatGPT 内打开答题窗口'
    }
  }]}));

  registerAppResource(server,'data-analysis-quiz-view',QUIZ_URI,{},async()=>({contents:[{
    uri:QUIZ_URI,
    mimeType:RESOURCE_MIME_TYPE,
    text:quizHtml,
    _meta:{
      ui:{prefersBorder:false,csp:{connectDomains:[],resourceDomains:[]}},
      'openai/ui':{availableDisplayModes:['fullscreen']},
      'openai/widgetDescription':'资料分析5题答题窗口'
    }
  }]}));

  registerAppTool(server,'show_data_analysis_quiz',{
    title:'打开资料分析练习',
    description:'呈现一篇资料和固定5题的交互式答题器。title为标题；material使用Markdown，支持多段文字、**加粗**及管道表格；questions包含不重复的1—5题号、题干、A/B/C/D。题目由调用方动态提供，不包含正确答案。交卷前不要公布答案，等用户交卷结果再分析。',
    inputSchema:{title:text,material:text,questions:z.array(question).length(5)},
    outputSchema:{quizId:z.string().uuid(),quiz:z.object({title:text,material:text,questions:z.array(question).length(5)})},
    annotations:{readOnlyHint:true,destructiveHint:false,idempotentHint:false,openWorldHint:false},
    securitySchemes:[{type:'noauth'}],
    _meta:{
      ui:{resourceUri:LAUNCHER_URI},
      'openai/outputTemplate':LAUNCHER_URI,
      'openai/toolInvocation/invoking':'正在准备答题器…',
      'openai/toolInvocation/invoked':'答题器已准备好',
      securitySchemes:[{type:'noauth'}]
    }
  },async(args)=>{
    try {
      const quiz=validateQuiz(args);
      return {
        content:[{type:'text',text:`《${quiz.title}》已准备好，共5题。`}],
        structuredContent:{quizId:randomUUID(),quiz}
      };
    } catch(e) {
      return {isError:true,content:[{type:'text',text:e.message}]};
    }
  });

  registerAppTool(server,'submit_data_analysis_quiz',{
    title:'提交资料分析答卷',
    description:'由答题组件提交5题选择和总用时。不判分，不公布正确答案。',
    inputSchema:{
      quizId:z.string().uuid(),
      submissionId:z.string().uuid(),
      title:text,
      answers:z.array(z.object({id:z.number().int().min(1).max(5),choice:z.enum(['A','B','C','D'])})).length(5),
      elapsedSeconds:z.number().int().min(0).max(31536000)
    },
    annotations:{readOnlyHint:true,destructiveHint:false,idempotentHint:true,openWorldHint:false},
    securitySchemes:[{type:'noauth'}],
    _meta:{ui:{visibility:['app']},securitySchemes:[{type:'noauth'}]}
  },async(args)=>{
    try {
      const result=makeResult(args);
      return {structuredContent:result,content:[{type:'text',text:result.text}]};
    } catch(e) {
      return {isError:true,content:[{type:'text',text:e.message}]};
    }
  });

  return server;
}

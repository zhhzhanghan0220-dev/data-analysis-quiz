import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { createQuizServer } from './mcp.mjs';

const launcherHtml = readFileSync(new URL('../dist/launcher.html', import.meta.url), 'utf8');
const quizHtml = readFileSync(new URL('../dist/quiz.html', import.meta.url), 'utf8');
const port = Number(process.env.PORT || 8787);
const MCP_PATH = '/mcp';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Expose-Headers', 'Mcp-Session-Id');
}

const http = createServer(async (req, res) => {
  if (!req.url) {
    res.writeHead(400).end('Missing URL');
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host ?? 'localhost'}`);

  if (req.method === 'GET' && url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' }).end('{"ok":true}');
    return;
  }

  if (req.method === 'GET' && url.pathname === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }).end(
      '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>资料分析答题器</title><h1>资料分析答题器已启动</h1><p>请在 ChatGPT 中连接 /mcp。</p></html>'
    );
    return;
  }

  if (req.method === 'OPTIONS' && url.pathname === MCP_PATH) {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'content-type, mcp-session-id',
      'Access-Control-Expose-Headers': 'Mcp-Session-Id',
    });
    res.end();
    return;
  }

  const MCP_METHODS = new Set(['POST', 'GET', 'DELETE']);
  if (url.pathname === MCP_PATH && req.method && MCP_METHODS.has(req.method)) {
    setCors(res);
    const server = createQuizServer({ launcherHtml, quizHtml });
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true,
    });

    res.on('close', () => {
      void transport.close();
      void server.close();
    });

    try {
      await server.connect(transport);
      await transport.handleRequest(req, res);
    } catch (e) {
      console.error('MCP request failed:', e?.stack || e?.message || e);
      if (!res.headersSent) res.writeHead(500).end('Internal server error');
    }
    return;
  }

  res.writeHead(404).end('Not Found');
});

http.listen(port, '0.0.0.0', () => console.log(`资料分析答题器 http://localhost:${port}${MCP_PATH}`));
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => http.close(() => process.exit(0)));
